
<!DOCTYPE html>
<html class="no-js">
<head>



<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

<!-- Set Current Locale -->


<title>Page Not Found</title>


<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />

<link rel="stylesheet" href="/dialogdocroot/content/css/main.min.css">
<link rel="stylesheet" href="/dialogdocroot/content/css/main-plus.min.css">
<link rel="shortcut icon" href="/dialogdocroot/content/images/favicon.ico" />

<!--  
Including JQuery library. This was initially in pageStartScript.jsp and moved to here. 
Because pageStartScript.jsp was currently included at the footer and JQuery functions need be accessed from the body of several pages. 
-->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="/vendor/jquery-1.10.1.min.js"><\/script>')</script>


<!-- Facebook Pixel Code [ATGONLINE-870]-->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','//connect.facebook.net/en_US/fbevents.js');
fbq('init', '729621640477633');
fbq('track', "PageView");</script>
<noscript>
<img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=729621640477633&ev=PageView&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

</head>
<body>	
	<!-- Google Tag Manager -->
	<noscript>
		<iframe src="//www.googletagmanager.com/ns.html?id=GTM-MTL74W" height="0" width="0" style="display: none; visibility: hidden"></iframe>
	</noscript>
	  
	 	 
	<!-- Pingdome Script -->
	<script>
var _prum = [['id', '54b796c9abe53d7b5b0a11cd'],
             ['mark', 'firstbyte', (new Date()).getTime()]];
(function() {
    var s = document.getElementsByTagName('script')[0]
      , p = document.createElement('script');
    p.async = 'async';
    p.src = '//rum-static.pingdom.net/prum.min.js';
    s.parentNode.insertBefore(p, s);
})();
</script>
	<script>
		(function(w, d, s, l, i) {
			w[l] = w[l] || [];
			w[l].push({
				'gtm.start' : new Date().getTime(),
				event : 'gtm.js'
			});
			var f = d.getElementsByTagName(s)[0], j = d.createElement(s), dl = l != 'dataLayer' ? '&l='
					+ l
					: '';
			j.async = true;
			j.src = '//www.googletagmanager.com/gtm.js?id=' + i + dl;
			f.parentNode.insertBefore(j, f);
		})(window, document, 'script', 'dataLayer', 'GTM-MTL74W');
	</script>
	<!-- End Google Tag Manager -->
	<!-- Mouse Flow Tracker -->
	<!-- This will track the mouse flow of all the jsp pages which uses this file -->
	
			<script type="text/javascript">
				var _mfq = _mfq || [];
				(function() {
					var mf = document.createElement("script");
					mf.type = "text/javascript";
					mf.async = true;
					mf.src = "//cdn.mouseflow.com/projects/626dbcfd-55d0-4ccd-af23-5b21711c0f96.js";
					document.getElementsByTagName("head")[0].appendChild(mf);
				})();
			</script>
		
	<!-- End Mouse Flow Tracker -->	
	<header id="siteheader" class="cd-main-header">
		<div class="header-wrap">
			<div class="group container">
				
	<h1>	
					<a href="/about/index.jsp" title="Dialog" class="home-link"><img src="/dialogdocroot/content/images/dialog_logo.png" alt="Dialog" /></a>
				</h1>
				<ul class="preferences">
					

  <li class="dropdown personal-preferences">
    
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">පිලිබඳ<i class="fa fa-angle-down"></i></a>
        <ul class="dropdown-menu">
          <li><a href="#" onclick="javascript: submitSitePrefForm('personalForm');return false;">පුද්ගලික</a></li>
          <li><a href="#" onclick="javascript: submitSitePrefForm('businessForm');return false;">ව්‍යාපාරික</a></li>
          <li><a href="#" class="active" onclick="javascript: submitSitePrefForm('aboutForm');return false;">පිලිබඳ</a></li> </ul> 
  </li>

  <form action="/dlg/index.jsp" method="post" name="personalForm" id="personalForm">
    <input type="hidden" name="preference" value="personal">
  </form>
    
  <form action="/dlg/business/index.jsp" method="post" name="businessForm" id="businessForm">
   <input type="hidden" name="preference" value="business">
  </form>

  <form action="/dlg/about/index.jsp" method="post" name="aboutForm" id="aboutForm">
   <input type="hidden" name="preference" value="about">
  </form>
    
  <script>
  function submitSitePrefForm(formId){
    $("#" + formId).submit()
  }
  </script>
  

				</ul>
				<nav id="sitenav">
					<div class="navbar" role="navigation">
						<ul id="main_tabs" class="nav nav-tabs navbar-toggle">
							<li>
							<!-- <a href="#reload" data-toggle="tab"><span class="menu-text">Top Up / Pay Bill</span></a> -->
							
										<!-- 				not logged	 -->
										<a href="/dlg/browse/reloadPayBillOnline.jsp"><span class="menu-text">රීලෝඩ් කරන්න/ බිල් ගෙවන්න</span>	</a>	
																		
							
							</li>
							<li class="more_menu"><a href="#menu" data-toggle="tab"><span class="menu-text">මෙනුව</span></a></li>
						</ul>
						<div class="tab-content">
							<div class="tab-pane" id="map">
								<div>
									<h3>
										We have detected you are currently in <label id="address"></label>
									</h3>
									<div>
										<div class="coverage">
											<div>VOICE coverage</div>
											<div>
												<div class="progress">
													<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
														<span class="sr-only">60% Complete</span>
													</div>
												</div>
											</div>
										</div>
										<div class="coverage">
											<div>4G coverage</div>
											<div>
												<div class="progress">
													<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 30%;">
														<span class="sr-only">60% Complete</span>
													</div>
												</div>
											</div>
										</div>
										<div>
											<div class="search-action">
												<form class="main-search" action="#" method="post">
													<div class="search-keywords" data-placement="bottom" data-toggle="popover">
														<input id="main-search-keywords" type="input" data-placement="right" data-toggle="popover" value="" aria-label="Search" placeholder="Search" name="keywords" placeholder="Search">
														<button id="main-submit-search" data-placement="bottom" data-toggle="popover" type="submit" name="submit">
															<i class="fa fa-search"></i>
														</button>
													</div>
												</form>
											</div>
											<!-- /.search-action -->
										</div>
									</div>
								</div>
							</div>
							<div class="tab-pane" id="account">
								<ul>
									<li>
												<a href="/dlg/myaccount/login.jsp">කරුණාකර ලොගින් වෙන්න</a>	</li>
								</ul>
							</div>
							<div class="tab-pane" id="reload">
								<ul>
									<li><a href="/dlg/browse/reloadPayBillOnline.jsp">Reload</a></li>
								</ul>
							</div>
							<div class="tab-pane navbar-collapse collapse" id="menu">
								<div id="main-menu" class="main-menu">
									
	<ul>
		<li class="three-menu"><a href="#">
				Overview&#160;
				<i class="fa fa-angle-down"></i>
			</a>
			<div class="menu-box">
				<ul id="shop" class="menu-box-inner">
					
	<li>	
				<a href="">දළ විශ්ලේෂණයක්<i class="fa fa-angle-down"></i></a>
				<h3 class="menu_title">
					
	<a>දළ විශ්ලේෂණයක්</a>	
	</h3>	
	<ul>								   
			<li><a href="/group-overview">Group Overview</a></li>								   
			<li><a href="/our-values">Our Values</a></li>								   
			<li><a href="/corporate-information">Corporate Information</a></li>								   
			<li><a href="/fact-sheet">Fact Sheet</a></li>								   
			<li><a href="/ahievements">Achievements</a></li>								   
			<li><a href="/browse/news.jsp">News & Media</a></li>								   
			<li><a href="/careers">Careers</a></li>	
	</ul>	</li>

	<li>	
				<a href="">Structure &amp; Management<i class="fa fa-angle-down"></i></a>
				<h3 class="menu_title">
					
	<a>Structure &amp; Management</a>	
	</h3>	
	<ul>								   
			<li><a href="/board-of-directors">Board of Directors</a></li>								   
			<li><a href="/shareholding-structure">Shareholding Stucture</a></li>								   
			<li><a href="/senior-management">Senior Management</a></li>	
	</ul>	</li>

	<li>	
				<a href="">Governance<i class="fa fa-angle-down"></i></a>
				<h3 class="menu_title">
					
	<a>Governance</a>	
	</h3>	
	<ul>								   
			<li><a href="/core-principles">Core Principles</a></li>								   
			<li><a href="/articles-of-association">Articles of Association</a></li>	
	</ul>	</li>

				</ul>
				<!-- /menu-box-inner -->
			</div>
			<!-- /menu-box --></li>



		<li class="four-menu"><a href="#">
				Investors&#160;
				<i class="fa fa-angle-down"></i>
			</a>
			<div class="menu-box">
				<ul id="shop" class="menu-box-inner">
					
	<li>	
				<a href="">Financials<i class="fa fa-angle-down"></i></a>
				<h3 class="menu_title">
					
	<a>Financials</a>	
	</h3>	
	<ul>								   
			<li><a href="/quarterly-reports">Quarterly Reports</a></li>								   
			<li><a href="/annual-reports">Annual Reports</a></li>								   
			<li><a href="/financial-other-reports">Other Reports</a></li>								   
			<li><a href="/financial-announcements">Announcements</a></li>	
	</ul>	</li>

	<li>	
				<a href="/share-price">Share Price<i class="fa fa-angle-down"></i></a>
				<h3 class="menu_title">
					
							<a href="/share-price">Share Price</a>	
	</h3>	
	<ul>	
	</ul>	</li>

	<li>	
				<a href="">Shareholder Services<i class="fa fa-angle-down"></i></a>
				<h3 class="menu_title">
					
	<a>Shareholder Services</a>	
	</h3>	
	<ul>								   
			<li><a href="/shareholder-notifications">Shareholder Notifications</a></li>								   
			<li><a href="/shareholder-printable-forms">Printable Forms</a></li>	
	</ul>	</li>

	<li>	
				<a href="">Investor Support<i class="fa fa-angle-down"></i></a>
				<h3 class="menu_title">
					
	<a>Investor Support</a>	
	</h3>	
	<ul>								   
			<li><a href="/financial-calendar">Financial Calendar</a></li>								   
			<li><a href="/investor-analyst-coverage">Analyst Coverage</a></li>								   
			<li><a href="/investor-email-alerts">E-mail Alerts</a></li>	
	</ul>	</li>
					
				</ul>
				<!-- /menu-box-inner -->
			</div>
			<!-- /menu-box --></li>
			
			

			
		<li class="four-menu"><a href="#">
				Sustainability
				<i class="fa fa-angle-down"></i>
			</a>
			<div class="menu-box">
				<ul id="shop" class="menu-box-inner">
					
	<li>	
				<a href="">Overview<i class="fa fa-angle-down"></i></a>
				<h3 class="menu_title">
					
	<a>Overview</a>	
	</h3>	
	<ul>								   
			<li><a href="/sustainability-philosophy">Sustainability Philosophy</a></li>								   
			<li><a href="/sustainability-reports">Sustainability Reports</a></li>	
	</ul>	</li>

	<li>	
				<a href="">Digital Inclusion<i class="fa fa-angle-down"></i></a>
				<h3 class="menu_title">
					
	<a>Digital Inclusion</a>	
	</h3>	
	<ul>								   
			<li><a href="/4as-philosophy">4As Philosophy</a></li>	
	</ul>	</li>

	<li>	
				<a href="">Engagement & Community Investments<i class="fa fa-angle-down"></i></a>
				<h3 class="menu_title">
					
	<a>Engagement & Community Investments</a>	
	</h3>	
	<ul>								   
			<li><a href="/browse/aboutInner.jsp?id=fld1910504">Product Responsibility</a></li>								   
			<li><a href="/browse/aboutInner.jsp?id=fld1910505">Dialog Foundation</a></li>	
	</ul>	</li>

	<li>	
				<a href="">Performance Measurement & Reporting<i class="fa fa-angle-down"></i></a>
				<h3 class="menu_title">
					
	<a>Performance Measurement & Reporting</a>	
	</h3>	
	<ul>								   
			<li><a href="/browse/aboutInner.jsp?id=fld1910506">Our People</a></li>								   
			<li><a href="/browse/aboutInner.jsp?id=fld1910507">Environment</a></li>	
	</ul>	</li>

				</ul>
				<!-- /menu-box-inner -->
			</div>
			<!-- /menu-box --></li>
			
			
		<li class="two-menu"><a href="#">
				Suppliers
				<i class="fa fa-angle-down"></i>
			</a>
			<div class="menu-box">
				<ul id="shop" class="menu-box-inner">
					 
	<li>	
	<ul>								   
			<li><a href="/become-an-approved-vendor">Become an Approved Vendor</a></li>								   
			<li><a href="/supplier-code-of-conduct">Supplier Code of Conduct</a></li>								   
			<li><a href="/latest-open-tenders">Latest Open Tendors</a></li>								   
			<li><a href="/supplier-support">Supplier Support</a></li>	
	</ul>	</li>

	</ul>	<!-- /menu-box-inner -->	</div>	<!-- /menu-box --></li>	</ul>

								</div>
								<!-- /#main-menu -->
							</div>
						</div>
					</div>
				</nav>
				<div class="search-action">
					<form id="searchFormId" name="searchForm" action="?_DARGS=/dlg/includes/header.jsp#" class="main-search" method="post"><div style="display:none"><input name="_dyncharset" value="UTF-8" type="hidden"/> </div><div style="display:none"><input name="_dynSessConf" value="8169836987169698666" type="hidden"/> </div>
						<div class="search-keywords" data-placement="bottom" data-toggle="popover" data-content="">
							<input data-placement="right" id="main-search-keywords" maxlength="80" dojoType="validation:SubmitButton" name="keyWords" value="" data-content="" data-toggle="popover" required="true" type="search" aria-label="Search"/><input name="_D:keyWords" value=" " type="hidden"/>
							<button id="submit-search" name="submit" type="submit" onclick="submit(document.searchForm);" data-toggle="popover" data-placement="bottom" data-content="">
								<i class="fa fa-search"></i>
							</button>
							<input name="search" value="search" type="hidden"/><input name="_D:search" value=" " type="hidden"/>
	</div>	<div style="display:none"><input name="_DARGS" value="/dlg/includes/header.jsp" type="hidden"/> </div></form>
				</div>
			</div>
			<!-- group -->
			<div class="top-action">
				<div class="top-action-box container">
					<!-- "main-actions"-->
					<div class="main-actions">
						<ul>
							<li class="user-link">
										<div class="popover-markup">
											<a href="#" class="btn btn-primary trigger"><i class="fa fa-user"></i><span>ලොග් වන්න / ලියාපදිංචි වන්න</span>
											</a>
											<div class="content hide">
												<h2>
													ලොග් වන්න
	</h2>	<fieldset>
<!--	JIRA : ATGONLINE-324 -->	
	<fieldset>
		<div class="col-md-6" style="overflow: hidden; padding-bottom: 20px;">
			<form method="POST" id="singleSignOn">
				
				
				<div class="line">
					<div class="field_wrapper">
						<label>Dialog Mobile Number</label>	
	<!-- ATGONLINE-2013 -->	
						<input type="hidden" id="appId" name="appId" value="NeSelf">
						<div class="input_wrapper">
							
								<input type="text" id="msisdnMConnect" name="msisdnMConnect" class="form-control"/>
							 
						</div>
					</div>
				</div>
				<div class="line">
					<div class="field_wrapper">
						<div class="input_wrapper">
							<button class="mconnectbtn" value="Sign In" type="button" ??? MyDialog_Disable_Login ??? id="singleSignOnButtonId" onclick="singleSignOn();" >
							</button>
						</div>
					</div>
				</div>
			</form>
		</div>
		<div class="col-md-6 or">
			<form method="POST" id="login_form" action="https://connect.dialog.lk/DialogConnect/UserLogin">
				<div class="line">
					<div class="field_wrapper">
						<label> පරිශීලක නම
	</label>	
						<input type="hidden" id="appId" name="appId" value="NeSelf">
						<div class="input_wrapper">
							<input type="text" id="textUsername" value="" name="textUsername" class="form-control" autocomplete="off"/>
						</div>
					</div>
				</div>
				<div class="line">
					<div class="field_wrapper">
						<label> මුරපදය
						</label>
						<div class="input_wrapper">
							<input type="password" id="textPassword" value="" name="textPassword" class="form-control" autocomplete="off">
						</div>
					</div>
				</div>
				<div class="line">


					<div>
						<button class="btn btn-primary" value="Sign In" type="submit" ??? MyDialog_Disable_Login ???>	ලොග් වන්න
						</button>
					</div>
				</div>
			</form>
			<form id="loginBySingleSignOnForm" method="post" action="https://connect.dialog.lk/DialogConnect/UserLogin">
				<input type="hidden" name="msisdn_login" id="msisdn_login" value="true" /> <input type="hidden" name="msisdn" id="msisdn" /> <input type="hidden" name="appId" id="appId" value="NeSelf">
				<input type="hidden" name="channelURL" id="channelURL" />
			</form>
			<div class="line last text-right">
				<div class="field_wrapper new_account">
					
					<form action="https://connect.dialog.lk/DialogConnect/signup.jsp">
						<p class="pull-left">
							<input type="hidden" id="appId" name="appId" value="NeSelf">
						</p>
						<input class="btn btn btn-gray" value="ලියාපදිංචි වීම" type="submit" ??? MyDialog_Disable_Login ??? />
					</form>
					<p class="pull-right">
						<a href="https://connect.dialog.lk/DialogConnect/forgotUnamePw.jsp?appId=NeSelf"><small> පරිශීලක නම/මුර පදය අමතකද?</small> </a>
					</p>
				</div>
			</div>
		</div> 
		<div class="remember-me clear">
			<input type="checkbox" name="remember-me" id="remember-me" value="Y"> <label class="inline_block"> මතක තබා ගන්න
	</label>	</div>	</fieldset>

	</fieldset>	</div>	</div>	</li>	<li></li>	<li>
										<!-- 				not logged	 -->
										<a class="header-main-link desktop btn btn-success" href="/dlg/browse/reloadPayBillOnline.jsp"> රීලෝඩ් කරන්න/ බිල් ගෙවන්න
	</a>	</li>	
							
							<li class="cart-link">
								<a href="/dlg/cart/cart.jsp" class="btn btn-gray"> 
									<i class="fa fa-shopping-cart"></i>
									<span class="cart" id="orderTotalCartBlock">
										
	
	<span class="items"></span>
	
	<em>	Cart Empty
	</em>	
									</span>
								</a>
							</li>
						</ul>
					</div>
					<!-- "lang-action"-->
					
	<div class="lang-action">
		<ul class="lang-preferences">
			
	<li>	<a href="/dlg/global/pageNotFound.jsp?locale=en_US">
	English	</a>
	</li>	<li>	<a class="active" href="/dlg/global/pageNotFound.jsp?locale=si_LK">
	සිංහල	</a>
	</li>	<li>	<a href="/dlg/global/pageNotFound.jsp?locale=ta_LK">
	தமிழ்	</a>
	</li>	
	</ul>	</div>
<form id="logoutFormId" name="logoutForm" action="/dlg/index.jsp?_DARGS=/dlg/includes/header.jsp.1" method="post"><div style="display:none"><input name="_dyncharset" value="UTF-8" type="hidden"/> </div><div style="display:none"><input name="_dynSessConf" value="8169836987169698666" type="hidden"/> </div>
						<!-- defines the URL to go to on success (relative to 'action')-->
						<input name="/lk/dialog/online/userprofiling/DialogProfileFormHandler.logout" value="Logout" type="hidden"/><input name="_D:/lk/dialog/online/userprofiling/DialogProfileFormHandler.logout" value=" " type="hidden"/><div style="display:none"><input name="_DARGS" value="/dlg/includes/header.jsp.1" type="hidden"/> </div></form>
				</div>
				<!-- /.top-action-box -->
			</div>
			<!-- /.top-action -->
		</div>
		<!-- /header-wrap -->
	</header>
	<script type="text/javascript">
		$(document)
				.ready(
						function() {
							if ('true' == '') {
								//var isChrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);
								var isSafari = /Safari/
										.test(navigator.userAgent)
										&& /Apple Computer/
												.test(navigator.vendor);
								if (isSafari) {
									var operatingSystem = navigator.platform;
									if (operatingSystem.indexOf("Win") != -1) {
										OSName = "Windows";
										alert("We recommend you to change the browser from Safari.");
									}
								}
							}
						});

		function submit(form) {
			form.submit();
		}

		function submitLogout() {
			//alert('');
			if ('' == 'success') {
				//alert('b');
				Selflogout();
				setTimeout(function() {
					$('#logoutFormId').submit();
				}, 500);
				//alert('You are successfully logged out');
			} else {
				$('#logoutFormId').submit();
			}
		}
		function ringTonePopuptest() {
			$("#test123").bPopup({
				fadeSpeed : 'slow',
				followSpeed : 1500,
				modalColor : 'black'
			});
		}
		</script>
	
	
	
	<script type="text/javascript">
		
		var msisdnMConnect = "";
	    var leftArrowCount ="0";
	
		function closePopup(){
			msisdnMConnect="";
			document.getElementById('msisdnMConnect').value = "";
			document.getElementById('msisdn').value = "";
			document.getElementById('msisdnPopUpId').innerHTML = "";
			//$("#singleSignOnPopup").innerHTML = "";
			//$("#singleSignOnTnCPopup").innerHTML = "";
			$("#mConetentContent").show();
			$("#timeOutConetent").hide();
			$("#mConnectRespMsg").hide();
			$('.popover #msisdnMConnect').val("");
			$("#singleSignOnPopup").bPopup().close();
			$("#singleSignOnTnCPopup").bPopup().close();

		}
		
		function tryAgain(validateGSMNo){
			
			var appId = document.getElementById('appId').value;
			
			if(msisdnMConnect==""){
				msisdnMConnect=$('.popover #msisdnMConnect').val();					
			}
			if (msisdnMConnect == "" || typeof msisdnMConnect === 'undefined') {
				msisdnMConnect = document.getElementById('msisdnMConnect').value;
			}
			

			if(validateGSMNo=='no'){
				$("#mConetentContent").show();
				$("#timeOutConetent").hide();
				$.ajax({
					type : "POST",
					url : "/dlg/myaccount/gadgets/dialogSingleSignOn.jsp",
					data : {
						msisdn : "" + msisdnMConnect + "",
						appId : "" + appId + "",
						validateGSM : "" + validateGSMNo + ""
					},
					success : function(result) {
						
						if (result == 'error_return_url') {
							$('#mConnectRespMsg').html('Login Timeout');
							$("#mConetentContent").hide();
							$("#timeOutConetent").show();
	 					}else if (result == 'failed_ussd') {
	 						$('#mConnectRespMsg').html('Login Error. Please try again later');
							$("#mConetentContent").hide();
							$("#timeOutConetent").show();
	 					}else if (result == 'error_request') {
	 						$('#mConnectRespMsg').html('Login Error. Please try again later');
							$("#mConetentContent").hide();
							$("#timeOutConetent").show();
	 					}else if (result == 'rejected_by_user') {
	 						msisdnMConnect="";
	 						document.getElementById('msisdnMConnect').value = "";
	 						document.getElementById('msisdn').value = "";
	 						document.getElementById('msisdnPopUpId').innerHTML = "";
	 						$("#singleSignOnPopup").bPopup().close();
	 						$("#singleSignOnTnCPopup").bPopup().close();
	 					}else if (result == 'error_in_operation') {
	 						$('#mConnectRespMsg').html('Login Error. Please try again later');
							$("#mConetentContent").hide();
							$("#timeOutConetent").show();
	 					} else  if (result == 'showTnC') {
	 						$("#singleSignOnPopup").bPopup().close();
	 						$('#singleSignOnTnCPopup') .bPopup(
							{
								fadeSpeed : 'slow',
								followSpeed : 1500,
								modalColor : 'black'
							});
						} else {
							document.getElementById('channelURL').value = result;
							$('#loginBySingleSignOnForm').submit();
						}
					},
				});	
			}else{
				$("#mConetentTCContent").show();
				$("#timeOutTCConetent").hide();
				singleSignOn();
			}
		} 
		
		
		function singleSignOn() {
			msisdnMConnect=$('.popover #msisdnMConnect').val();					
			if (msisdnMConnect == "" || typeof msisdnMConnect === 'undefined') {
				msisdnMConnect = document.getElementById('msisdnMConnect').value;
			}
			var firstTwoNumbers = msisdnMConnect.substring(0,2);
			var firstThreeNumbers = msisdnMConnect.substring(0,3);
			var appId = document.getElementById('appId').value;
			var validateGSMYes="yes";
			var validateGSMNo="no";
			document.getElementById('msisdn').value = msisdnMConnect;
			document.getElementById('msisdnPopUpId').innerHTML = msisdnMConnect;

			if (msisdnMConnect != "" && !isNaN(msisdnMConnect) && (msisdnMConnect.length == 10 || msisdnMConnect.length == 9) && (firstTwoNumbers=='77' || firstTwoNumbers=='76' || firstThreeNumbers=='076' || firstThreeNumbers=='077')) {
				$('.popover-markup > .trigger').popover('hide');
				var showTnC='no'
				$('#loginForm').hide();
				$.ajax({
					type : "POST",
					url : "/dlg/myaccount/gadgets/dialogSingleSignOn.jsp",
					data : {
						msisdn : "" + msisdnMConnect + "",
						appId : "" + appId + "",
						validateGSM : "" + validateGSMYes + ""
					},
					success : function(result) {
						if (result == 'error_gsm') {
							$('#singleSignOnPopup') .bPopup(
									{
										fadeSpeed : 'slow',
										followSpeed : 1500,
										modalColor : 'black'
									});
							$('#mConnectRespMsg').html('Not a valid GSM&#160;Number');
							$("#mConetentContent").hide();
							$("#timeOutConetent").show();
						}else if(result == 'valid_gsm'){
							
							$('#singleSignOnPopup') .bPopup(
							{
								onClose : function() {
									$("#loginForm").show();
								},
								fadeSpeed : 'slow',
								followSpeed : 1500,
								modalColor : 'black'
							});
							
							$.ajax({
								type : "POST",
								url : "/dlg/myaccount/gadgets/dialogSingleSignOn.jsp",
								data : {
									msisdn : "" + msisdnMConnect + "",
									appId : "" + appId + "",
									validateGSM : "" + validateGSMNo + ""
								},
								success : function(result) {
									$('#singleSignOnPopup') .bPopup(
											{
												onClose : function() {
													$("#loginForm").show();
												},
												fadeSpeed : 'slow',
												followSpeed : 1500,
												modalColor : 'black'
											});
									if (result == 'error_return_url') {
										$('#mConnectRespMsg').html('Login Timeout');
										$("#mConetentContent").hide();
										$("#timeOutConetent").show();
				 					}else if (result == 'failed_ussd') {
				 						
				 						$('#mConnectRespMsg').html('Login Error. Please try again later');
										$("#mConetentContent").hide();
										$("#timeOutConetent").show();
				 					}else if (result == 'error_request') {
				 						
				 						$('#mConnectRespMsg').html('Login Error. Please try again later');
										$("#mConetentContent").hide();
										$("#timeOutConetent").show();
				 					}else if (result == 'error_in_operation') {
				 								
				 						$('#mConnectRespMsg').html('Login Error. Please try again later');
										$("#mConetentContent").hide();
										$("#timeOutConetent").show();
				 					} else if (result == 'rejected_by_user') {
				 						msisdnMConnect="";
				 						document.getElementById('msisdnMConnect').value = "";
				 						document.getElementById('msisdn').value = "";
				 						document.getElementById('msisdnPopUpId').innerHTML = "";
				 						$("#singleSignOnPopup").bPopup().close();
				 						$("#singleSignOnTnCPopup").bPopup().close();										
				 					} else  if (result == 'showTnC') {
				 						$("#singleSignOnPopup").bPopup().close();
				 						$('#singleSignOnTnCPopup') .bPopup(
										{
											onClose : function() {
											$("#loginForm").show();
											},
											fadeSpeed : 'slow',
											followSpeed : 1500,
											modalColor : 'black'
										});
									} else {
										document.getElementById('channelURL').value = result;
										$('#loginBySingleSignOnForm').submit();
									}
								},
							});							
							
						} else  if (result == 'showTnC') {
	 						$("#singleSignOnPopup").bPopup().close();
	 						$('#singleSignOnTnCPopup') .bPopup(
							{
								onClose : function() {
								$("#loginForm").show();
								},
								fadeSpeed : 'slow',
								followSpeed : 1500,
								modalColor : 'black'
							});
						}
					},beforeSend : function() {
						$.ajax({
								url : "/dlg/browse/gadgets/common/waitPopUp.jsp",
								data : {

							},
							success : function(result) {	
								$("#popUpMConnectWaitMessage").html(result);
								$('#popUpMConnectWaitMessage').bPopup({
																	fadeSpeed : 'slow',
																	followSpeed : 1500,
																	modalColor : 'black'
	
																});

							}
						});
					},
					complete : function() {
						$("#popUpMConnectWaitMessage").remove();
					}
					
					
				});				
			} else {
				alert('Not a Dialog Number');
				document.getElementById('msisdnMConnect').value = "";
				document.getElementById('msisdn').value = "";
				document.getElementById('msisdnPopUpId').innerHTML = "";
				$("#singleSignOnPopup").bPopup().close();
				$("#singleSignOnTnCPopup").bPopup().close();
				$('.popover #msisdnMConnect').val("");
			}
		}
		
		function tnCCancel(){
			document.getElementById('msisdnMConnect').value = "";
			document.getElementById('msisdn').value = "";
			document.getElementById('msisdnPopUpId').innerHTML = "";
			$("#singleSignOnPopup").bPopup().close();
			$("#singleSignOnTnCPopup").bPopup().close();	
			$('.popover #msisdnMConnect').val("");
		}
		
		function tnCfunction(){
			
			var isChecked  =document.getElementById('tncAcceptanceBoxId').checked;
			var appId = document.getElementById('appId').value;
			if(msisdnMConnect==""){
				msisdnMConnect=$('.popover #msisdnMConnect').val();					
			}
			if (msisdnMConnect == "" || typeof msisdnMConnect === 'undefined') {
				msisdnMConnect = document.getElementById('msisdnMConnect').value;
			}
			if(isChecked){
				$('#singleSignOnPopup') .bPopup(
				{
					onClose : function() {
						$("#loginForm").show();
					},
					fadeSpeed : 'slow',
					followSpeed : 1500,
					modalColor : 'black'
				});
				
				var showTnC = "yes";
	 			$.ajax({
	 				type : "POST",
	 				url : "/dlg/myaccount/gadgets/dialogSingleSignOn.jsp",
	 				data : {
	 					msisdn : "" + msisdnMConnect + "",
	 					appId : "" + appId + "",
	 					showTnC : "" + showTnC + ""
	 				},
	 				success : function(result) {
	 					if (result == 'error_return_url') {
	 						$("#singleSignOnPopup").bPopup().close();
	 						$('#mConnectTCRespMsg').html('Login Timeout');
							$("#mConetentTCContent").hide();
							$("#timeOutTCConetent").show();
	 					}else if (result == 'failed_ussd') {
	 						$("#singleSignOnPopup").bPopup().close();
	 						$('#mConnectTCRespMsg').html('Login Error. Please try again later');
							$("#mConetentTCContent").hide();
							$("#timeOutTCConetent").show();
	 					}else if (result == 'error_request') {
	 						$("#singleSignOnPopup").bPopup().close();
	 						$('#mConnectTCRespMsg').html('Login Error. Please try again later');
							$("#mConetentTCContent").hide();
							$("#timeOutTCConetent").show();
	 					}else if (result == 'rejected_by_user') {
	 						document.getElementById('msisdnMConnect').value = "";
	 						document.getElementById('msisdn').value = "";
	 						document.getElementById('msisdnPopUpId').innerHTML = "";
	 						$("#singleSignOnPopup").bPopup().close();
	 						$("#singleSignOnTnCPopup").bPopup().close();  
	 						
	 					}else if (result == 'error_in_operation') {
	 						$("#singleSignOnPopup").bPopup().close();
	 						$('#mConnectTCRespMsg').html('Login Error. Please try again later');
							$("#mConetentTCContent").hide();
							$("#timeOutTCConetent").show();
	 					} else {
	 						document.getElementById('channelURL').value = result;
	 						$('#loginBySingleSignOnForm').submit();
	 					}
	 				},
	 			});
			}else{
				alert('Please accept terms and conditions');
			}
			
		}
	
		
	</script>
	
	<div align="center" id="popUpMConnectWaitMessage" style="text-align: center;width: auto; position:absolute; left:35%; top:20%;"></div>
		<center>
		
	<div class="modal-dialog"  id="singleSignOnPopup" style="display: none; background-color: white; z-index: 11111011;">
		<div class="modal-content">
			<div class="modal-body">
				<div class="MobBk">
					<div id="Mobile-Connect">
						<section>
					
							<div class="MobileConSing">
								<header>
									<div class="Logos">
										<a href="#" title="Dialog Logo"><img src="/dialogdocroot/content/images/home/dialog-logo.png" width="95" height="58" alt="Dialog Logo" class="Dialog-Logo alignL"></a> <a href="#"><img
											src="/dialogdocroot/content/css/images/m-connect.png" width="115" height="52" alt="connect" class=" alignL"></a>
									</div>
								</header>
								<div class="Clear"></div>
								<div id="mConetentContent" class="TextC">
								<h1 class="PurpBorder">
									Mobile Verification
								</h1>
								<div class="Content">
								
									
										<p>
											You are trying to login from
											&nbsp; <div id="msisdnPopUpId"></div>
											Select
											<strong>"OK"</strong>
											on your Mobile Phone to complete login
	</p>	<p>	<span lang="en-US"><font size="2" face="Calibri,sans-serif"><span style="font-size:11pt;"><font size="2" face="Arial,sans-serif" color="#3F3F3F"><span style="font-size:9.5pt;background-color:white;">Please dial #124#</span></font><font size="2" face="Arial,sans-serif" color="#3F3F3F"><span style="font-size:9.5pt;background-color:white;"> </span></font><font size="2" face="Arial,sans-serif" color="#3F3F3F"><span style="font-size:9.5pt;background-color:white;">or cancel and retry to login if you haven't received the verification prompt<br /></span></font></span></font></span>
											&nbsp;
										</p>
										
										<a href="#" class="push_r20"  onclick="javascript:closePopup();" aria-hidden="true">
			                            	අවලංගු කරන්න
	                                	</a>
                                		
									</div>
									
								</div>
								
								<div id="timeOutConetent"  style="display: none;" class="TextC">
								<h1 class="PurpBorder">
									Mobile Number Verification Error
								</h1>
								<div class="Content">
								
									
										<p>
											
											<div id="mConnectRespMsg"> </div>
											
                               
										</p>
										
										 <a href="#" class="push_r20"  onclick="javascript:tryAgain('no');" aria-hidden="true">
                                    Try Again
                                </a>
										&nbsp;
										<a href="#" class="push_r20"  onclick="javascript:closePopup();" aria-hidden="true">
                                    අවලංගු කරන්න
                                </a>
                               
                                		<p>
											
											&nbsp;
										</p>
                                
									</div>
									
								</div>
								
								
									
								
							</div>
						</section>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="modal-dialog" id="singleSignOnTnCPopup" style="display: none; background-color: white; position: absolute; overflow: scroll; height: 300px;">
		<div class="modal-content">
			<div class="modal-body">
				<div class="MobBk">
					<div id="Mobile-Connect-Tc">
						<section>
							<div class="MobileConSing">
								<header>
									<div class="Logos">
										<a href="#" title="Dialog Logo"><img src="/dialogdocroot/content/images/home/dialog-logo.png" width="95" height="58" alt="Dialog Logo" class="Dialog-Logo alignL"></a> <a href="#"><img
											src="/dialogdocroot/content/css/images/m-connect.png" width="115" height="52" alt="connect" class=" alignL"></a>
									</div>
								</header>
								<div class="Clear"></div>
								<div id="mConetentTCContent" class="TextC">
								<h1 class="PurpBorder">
									Terms And Conditions
								</h1>
								<div class="Content">
									<div class="TextC">
										<div class="Clear"></div>
										<section>
											<p>Dialog Axiata PLC (hereinafter referred to as "Dialog" "us" "we" or "our") is committed to respecting your privacy and to complying with any applicable data protection and privacy
												laws when providing the Mobile Connect service (hereinafter referred to as the "Service"). We are providing this Privacy Policy Statement to help you understand how we collect, use and
												protect your information when you sign up for the Service and use the Service to access 3rd party websites and applications. We wish to help you make informed decisions, so please take a
												few moments to read the sections below and learn how we may use your personal information.</p>
											<ol>
												<li>Service (hereinafter referred to as the "Service") is offered by Dialog Axiata PLC</li>
												<li>What is Mobile Connect
													<ol>
														<li>Mobile Connect is a user identity solution that allows you to securely login to any third party website or an application using your mobile phone to authenticate the login
															transaction.</li>
														<li>With Mobile Connect your mobile phone number (hereinafter referred to as the "MSISDN") is used as the primary user identifier and your mobile phone is used as the authentication
															device.</li>
														<li>Dialog Connect: - Login service provided by Dialog for its customers to login to web portals provided by Dialog using a single username and a password.</li>
													</ol>
												</li>
												<li>How Mobile Connect works
													<ol>
														<li>Connect account is created for you on following scenarios;
															<ol>
																<li>You already have a Dialog Connect account and have attached a Mobile Connection to your Dialog Connect account</li>
																<li>You create a Dialog Connect account and add a Mobile Connection under Dialog Connect account</li>
																<li>You have used anonymous login or option provided in Dialog Connect integrated web portal/application</li>
																<li>You are trying to login to a Mobile Connect integrated website/application by clicking on Mobile Connect button provided and create a Mobile Connect account during the login
																	process by accepting these T&amp;C</li>
																<li>You visit Mobile Connect user portal provided by Dialog and chose to create a Mobile Connect account.</li>
															</ol>
														</li>
														<li>You only need to provide your MSISDN (Mobile Phone Number) if Connect registration is done using above step 3.1.4 or 3.1.5</li>
														<li>After you provide the MSISDN you will receive a network initiated (NI) USSD menu on your phone where you have to validate account creation.</li>
														<li>Mobile Connect uses two modes to get your authorization to a login request
															<ol>
																<li>You select Ok from the NI USSD menu</li>
																<li>You enter Your Mobile Connect PIN on the NI USSD menu.</li>
															</ol>
														</li>
														<li>You are prompted to create your Mobile Connect PIN number either during the registering to Mobile Connect account or during login to a service provider which needs PIN
															authentication</li>
														<li>The Mobile Connect PIN is a four digit number, and it is your responsibility to keep it confidential and Dialog shall not be liable for any unauthorized access to your Mobile
															Connect account due to any disclosure of your PIN. Dialog does not store/recored the PIN number in human readable form and it will be stored as an encrypted string and therefore the PIN
															will not be disclosed to any third party by Dialog.</li>
														<li>You shall not create Mobile Connect accounts using the MSISDNs of shared devices such as dongles and 3G routers, etc., due to the reason a third party that is using the shared
															connection, can have access to your Mobile Connect account through the shared devices.</li>
														<li>In an event you have forgotten the PIN or wants to reset the PIN, you can reset your PIN from Mobile Connect User portal or by calling Dialog support Services.</li>
													</ol>
												</li>
												<li>Information collection
													<ol>
														<li>For Mobile Connect accounts created using steps 3.1.3, 3.1.4 and 3.1.5 only information stored about you is your MSISDN.</li>
														<li>For Mobile Connect accounts created using steps 3.1.1 and 3.1.2 all the information you have updated on your profile are stored in Mobile Connect system</li>
														<li>You can view the information we have stored about you from your Mobile Connect profile page.</li>
													</ol>
												</li>
												<li>Using Mobile Connect to login to 3rd party applications/web sites</li>
												<li>We will undertake not to share your phone number with anyone or disclose your personal information with anyone unless you choose to and give your active consent.</li>
												<li>Please note that Dialog does not sell or pass your personal information to third parties (other than as set out in the paragraph above) unless you have given us permission or
													unless it is necessary to deliver the Services to you. Also make sure you read and understand the privacy policy of the 3rd party, you are login before giving your consent to sharing
													information with them via Mobile Connect.</li>
												<li>Protecting your privacy in Lost phone /SIM Swap and SIM cloning scenarios
													<ol>
														<li>With the Service, your identity is bonded to your mobile phone number (MSISDN). So your privacy can be compromised if you lose your phone, or swap SIM cards (either by you or by
															a malicious party), or a SIM cloning scenario</li>
														<li>If you lose your phone, please deactivate your Mobile Connect account by calling Dialog customer support.</li>
														<li>You can review third party sites/applications that you have logged into in the past using by accessing login history section of your Mobile Connect user portal. Make a habit of
															checking this information time to time as it could help you to identify if someone is miss using your Mobile Connect account. If you see suspected login transactions and wish to
															deactivate your Mobile Connect account you can do it by calling Dialog customer service hotline</li>
													</ol>
												</li>
												<li>Use of Cookies
													<ol>
														<li>Mobile Connect may store your mobile phone number that you have provided (during registration or login using Mobile Connect) on a browser cookie to provide better user
															experience.</li>
													</ol>
												</li>
												<li>Information security
													<ol>
														<li>Dialog recognizes that you are increasingly concerned about how to protect personal information from misuse and abuse and about privacy in general. We are constantly reviewing
															and enhancing our technical, physical and managerial procedures and rules to protect your personal data from unauthorised access, accidental loss and / or destruction. We use industry
															standard secure sockets layer (SSL) technology for example, to encrypt sensitive information. Please be aware that communications over the Internet, such as emails/webmails, are not
															secure unless they have been encrypted. Your communications may route through a number of countries before being delivered - this is the nature of the World Wide Web/Internet. We cannot
															accept responsibility for any unauthorised access or loss of personal information that is beyond our control.</li>
													</ol>
												</li>
												<li>When this privacy policy applies
													<ol>
														<li>This privacy policy only applies to the information you share directly with us. If any of the 3rd party is requesting additional information from you after you login with Mobile
															Connect, make sure you read the privacy policy of that party before sharing your information.</li>
													</ol>
												</li>
												<li>Changes
													<ol>
														<li>Our Privacy Policy may change from time to time. We will not reduce your rights under this Privacy Policy without your explicit consent. We will post any privacy policy changes
															on this page and, if the changes are significant, we will provide a more prominent notice (including, for certain services, email notification of privacy policy changes). We will also
															keep prior versions of this Privacy Policy in an archive for your review.</li>
													</ol>
												</li>
											</ol>
										</section>
										<div id="tnc" align="right">
											<a href="#" class="push_r20"  onclick="javascript:closePopup();"> Reject
											</a> &nbsp;&nbsp;&nbsp;&nbsp; <input type="checkbox" id="tncAcceptanceBoxId"> &nbsp;&nbsp; <a href="#" class="btn btn-primary"
												onclick="tnCfunction();"> Accept
											</a>
										</div>
									</div>
								</div>
								</div>
								
								<div id="timeOutTCConetent"  style="display: none;" class="TextC">
								<h1 class="PurpBorder">
									Mobile Number Verification Error
								</h1>
								<div class="Content">
								
									
										<p>
											
											<div id="mConnectTCRespMsg"> </div>
										</p>
										
										
										 <a href="#" class="push_r20"  onclick="javascript:tryAgain('yes');" aria-hidden="true">
                                    Try Again
                                </a>
										&nbsp;
										
										
										<a href="#" class="push_r20"  onclick="javascript:closePopup();" aria-hidden="true">
                                    අවලංගු කරන්න
 </a>	</div>	</div>	</div>	</section>	</div>	</div>	</div>	</div>	</div>

	</center>

	<main class="cd-main-content">
		
 <div class="page-info">

               

               <div class="container">

                       <div class="title-info">

                               <h2>Page Not Found</h2>

 

        </div>  </div>  </div>

 

        

        <div class="main-content">

               <div class="container">

                       <div class="row">

                       <div class="main col-md-9">

                       <div class="primary"><p>

                       <p>Sorry but the page you are looking for cannot be found.</p>

<p>You may want to try looking through the following sections :</p>

<div class="row">

<div class="col-md-4">

<h4>Explore &amp; Shop</h4>

<ul class="bullets">

    <li><a href="/mobile-products-and-services">Mobile</a></li>

    <li><a href="/fixed-line-connections">Fixed Line </a></li>

    <li><a href="/broadband">Broadband</a></li>

    <li><a href="/television">Television</a></li>

    <li><a href="/international">International</a></li>

</ul>

<h4>My Account</h4>

<ul class="bullets">

    <li><a href="/dlg/browse/myDialog.jsp">Account Summary</a></li>

</ul>

</div>

<div class="col-md-4">

<h4>Large Enterprise</h4>

<ul class="bullets">

    <li><a href="/dlg/browse/businessInner.jsp?id=onlinefld70105">Mobile Voice and Broadband</a></li>

    <li><a href="/dlg/browse/businessInner.jsp?id=onlinefld70084">Fixed Enterprise Solutions </a></li>

    <li><a href="/dlg/browse/businessInner.jsp?id=onlinefld90014">Bandwidth Services</a></li>

    <li><a href="/dlg/browse/businessInner.jsp?id=onlinefld70071">Enterprise Mobility Solutions</a></li>

    <li><a href="/dlg/browse/businessInner.jsp?id=onlinefld70099">Hosted and Managed Solutions</a></li>

</ul>

<h4>Emerging Business</h4>

<ul class="bullets">

    <li><a href="/dlg/browse/businessInner.jsp?id=onlinefld70061">OfficeNet</a></li>

    <li><a href="/dlg/browse/businessInner.jsp?id=onlinefld70058">Box Office </a></li>

    <li><a href="/dlg/browse/businessInner.jsp?id=onlinefld70058">Smart PABX</a></li>

    <li><a href="/dlg/browse/businessInner.jsp?id=onlinefld70056">Advanced Mobility Solutions</a></li>

</ul>

<h4>Global</h4>

<ul class="bullets">

    <li><a href="/dlg/browse/businessInner.jsp?id=onlinefld90017">Voice Services</a></li>

    <li><a href="/dlg/browse/businessInner.jsp?id=onlinefld90014">Bandwidth Services </a></li>

</ul>

</div>

<div class="col-md-4">

<h4>Customer Support</h4>

<ul class="bullets">

    <li><a href="/dlg/browse/faq.jsp">FAQ</a></li>

    <li><a href="/dlg/browse/reports.jsp?id=onlinefld90463">Billing</a></li>

    <li><a href="/dlg/browse/coverageMapLocateUs.jsp?coverageUrl=Dialog+Service+Points&amp;findServiceCentre=Find+Service+Centre">Service Points</a></li>

    <li><a href="/dlg/browse/coverageMapLocateUs.jsp?coverageUrl=Voice">Coverage Map</a></li>

    <li><a href="/dlg/browse/contactUs.jsp?hotline=7776">Contact Support</a></li>

</ul>

<h4>Contact Us</h4>

<ul class="bullets">

    <li><a href="https://www.facebook.com/dialog.lk">Facebook</a></li>

    <li><a href="http://www.twitter.com/dialoglk">Twitter</a></li>

    <li><a href="https://plus.google.com/+dialoglk/posts">G+</a></li>

</ul>

</div>

</div>

                       </p> 

                       </div>

                       </div>

                       <div class="sub col-md-3">

                       <div class="gray-block info_box">

                                      <!-- FeaturedItem as a common segment  -->            

                                      

                       <h3>

                               <a href="/dlg/browse/aboutPromo.jsp?id=onlinefld70051">Sustainability Report</a>

                       </h3>

                       <div class="wrap">

<!--                           <figure> -->

      <div class="img">

                                      

                                      <img alt="banner" src="/dialogdocroot/content/images/detail-images/about/sustainability.jpg">

                       </div>

<!--                           </figure> -->

                               

        <p>     Our sixth public disclosure on our Sustainability performance published in accordance with GRI’s G4 ‘Comprehensive’ guidelines&#39;

        </p>    

 

                               <ul class="gray">

                                      

        </ul>   <p>     

                                      <a href="/dlg/browse/aboutPromo.jsp?id=onlinefld70051"  class="know-more"> View More

                                      <i class="icon-chevron-circle-right"></i></a>

                               </p>

                       </div>

               

                       </div>

               

                       </div><!-- /.sub -->

                       </div><!-- /.row -->

               </div>

        </div>
    
<div class="secondary-info">
		<div class="container">
			<div class="help-box">
			<h2>
				උපදෙස් අවශ්‍යයද?
	</h2>	<p>	ඔබේ සහයට අප සැමවිට සූදානම්. අපගේ දැනුම් පදනම ගවේශණය කරන්න. නැතහොත් පැය 24 පුරා අප හා සම්බන්ධ වන්න.
	</p>	
			<a href="/browse/faq.jsp" class="btn btn-secondary btn-lg">උපදෙස් හා සහයෝග පිටුව වෙත යන්න</a>	</div>	</div><!-- /.container -->	</div><!-- /.quick_info -->

	<div class="links">
		<div class="container">
			<div class="row links_boxs">
				<div class="links_box col-md-3">
					<h2>
						භාණ්ඩ හා සේවා
	</h2>	<ul>								   
			<li><a href="/browse/mobile.jsp?category=mobile&categoryId=onlinecat3440050">ජංගම</a></li>								   
			<li><a href="/browse/fixedline.jsp?categoryId=onlinecat3800051">ස්ථාවර-සම්බන්ධතා</a></li>								   
			<li><a href="/browse/broadband.jsp?categoryId=onlinecat3440054">බ්‍රෝඩ්බෑන්ඩ්</a></li>								   
			<li><a href="/browse/television.jsp?categoryId=onlinecat3440055">රූපවාහිනී</a></li>								   
			<li><a href="/browse/international.jsp?categoryId=onlinecat3900050">ජාත්‍යන්තර</a></li>								   
			<li><a href="/loyalty">Loyalty</a></li>								   
			<li><a href="/careers">Careers</a></li>	
					</ul>
					
					
					
					
					
				</div>
				<div class="links_box col-md-3">
				<h2>
					හවුල්කරුවන් හා වෙනත් සේවාවන් 
	</h2>	<ul>	
	<li><a href="http://www.ezcash.lk/">eZ Cash</a></li>	
	<li><a href="/flysmiles">FlySmiLes</a></li>	
	<li><a href="http://www.ideamart.lk/">IdeaMart</a></li>	
	<li><a href="http://ringintones.dialog.lk/prbt2/">RingIn Tones</a></li>	
	<li><a href="http://www.starpoints.lk/">Starpoints</a></li>	
	<li><a href="http://www.wow.lk/">wOw.lk</a></li>	
	<li>	
 <strong> <a href="/partners-and-other-services">සියල්ල බලන්න 
                                                                    &nbsp;<span class="fa fa-chevron-circle-right"></span>
                                                                </a></strong> 
	</li>					
					</ul>
				</div>
				<div class="links_box col-md-3">
					<h2>
						සහාය
	</h2>	<ul>	
 <li> <a href="/dlg/browse/faq.jsp?id=faqPromo000318&type=element">ඩයලොග් ජංගම දුරකථන සම්බන්ධතාවයක් ලබාගන්නේ කෙසේද?</a>
 </li>	
 <li> <a href="/dlg/browse/faq.jsp?id=onlinepromocon12700005&type=element">මගේ ජංගම දුරකථන සම්බන්ධතාවයේ හිමිකාරීත්වය තහවුරු කරන්නේ කෙසේද?</a>
 </li>	
 <li> <a href="/dlg/browse/faq.jsp?id=onlinefaqpromo12800002&type=element">මගේ ඩයලොග් රූපවාහිනියේ බිල්පත පරීක්ෂා කරන්නේ කෙසේද?</a>
 </li>	
 <li> <a href="/dlg/browse/faq.jsp?id=faqPromo000016&type=element">4G Mobile LTE සේවාවෙන් මා හට ලැබෙන්නේ මොනවාද?</a>
 </li>	
 <li> <a href="/dlg/browse/faq.jsp?id=onlinefaqpromo12800016&type=element">ඔබේ ශේෂය අවසන් ද? අපගේ ස්වයංක්‍රීය ණය පහසුකම (Auto Loan) ලබාගන්න</a>
 </li>	
					
							<li class="more"><a href="/dlg/browse/faq.jsp"><strong>
							සියළු නිති අසන පැන බලන්න
						<span class="fa fa-chevron-circle-right"></span></strong></a></li>
					</ul>
				</div>
				<div class="links_box col-md-3">
					<h2>
						අප සමග සම්බන්ධ වන්න		</h2>

					
					
					<div class="">
              			<ul >
              			 <li>
                             	<a href="/dlg/browse/contactUs.jsp"><!-- <i class="info_icon ir">Info</i> -->
                             	    අප හා සම්බන්ධ විය හැකි ආකාර 
                             	</a>
                              </li>
                             <li>
                             	<a href="http://www.dialog.lk/chat">                             
                            		ඔන්ලයින් චැට්   
                             	</a>
                             </li>
                             <li>
                             	<a href="skype:dialog.skypeline?call">
                             		Skype 
                                </a>
                             </li>
                            

                             		<li><a href="mailto:
                             			service@dialog.lk&#160;   ">
                                         
                                         
                                         service@dialog.lk&#160;
                                           <!--  <i class="email_icon ir">Email</i> --></a></li>
                                        <!--     </a></li> -->
              			</ul>
					</div>
					
					
					<h2>
						ආවරණ කලාප සිතියම
	</h2>	<ul>	
						<li><a href="/dlg/browse/coverageMapLocateUs.jsp?coverageUrl=Voice"><strong>
							අපගේ ආවරණ කලාප ගැන තොරතුරු	
							<span class="fa fa-chevron-circle-right"></span>					
						</strong></a></li>
					</ul>
				</div>
			</div>
			<!-- /.links_boxs -->
		</div>
		<!-- container -->
	</div>
	<!-- /.links -->


<footer>
  	<div class="container">
  	<div class="row">
  		<div class="col-md-12">
	  		<div class="footer_box">
	  			<span class="icon-wrap">
	  				<a href="#" class="circle-icon scrollup"><i class="fa fa-chevron-up"></i><br />
	  					ඉහළට
	</a>	</span>	
					
					
					<ul class="main_share">

              		<li><a href="http://www.facebook.com/dialoglk"><i class="fa fa-facebook"></i></a></li>
              		<li><a href="http://twitter.com/dialoglk"><i class="fa fa-twitter"></i></a></li>
              		<li><a href="https://plus.google.com/108220764499314821314"><i class="fa fa-google-plus"></i></a></li>
					<li><a href="http://www.flickr.com/photos/dialogtelekom"><i class="fa fa-flickr"></i></a></li>
              		<li><a href="http://www.youtube.com/dialogtelekomplc"><i class="fa fa-youtube-play"></i></a></li>

					</ul>
					
					
				</div>
				<ul class="footer_links">
												   
			<li><a href="/index.jsp?preference=personal">පුද්ගලික</a></li>								   
			<li><a href="/index.jsp?preference=business">ව්‍යාපාරික</a></li>								   
			<li><a href="/about/index.jsp">පිලිබඳ</a></li>	
				</ul>
				<div class="copy">
					<p>
						සහ පිටපත; Dialog Axiata PLC. සියළු හිමිකම් ඇවිරිණි.		</p>	<ul>								   
			<li><a href="/browse/termsAndConditions.jsp?id=rpb4deb831863ff58e428067028c98d4b5">නීති සහ රෙගුලාසි</a></li>								   
			<li><a href="/privacy-policy">රහස්‍යභාවය පිළිබඳ ප්‍රතිපත්තිය</a></li>								   
			<li><a href="/browse/siteMap.jsp?categoryId=onlinedialogRoot">වෙබ් අඩවි සිතියම</a></li>	
	</ul>	</div>	</div>	</div><!-- /.row -->	</div><!-- /.container -->	<!-- Footer Section End-->
</footer>

	</main>
	<div class="cd-overlay"></div>
	
	
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/retina-1.1.0.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/collapse.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/transition.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/tab.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/modal.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/dropdown.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/jquery.flexslider.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/jquery.easing.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/jquery.mousewheel.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/jquery.equalheights.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/response.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/mainmenu.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/jquery.nouislider.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/tooltip.min.js"></script>
    <script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/popover.min.js"></script>
 	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/bbplayer.min.js"></script>  
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/jquery.sticky-kit.min.js"></script>	
	<script type="text/javascript" src="/dialogdocroot/content/javascript/main.min.js"></script>	
	<script type="text/javascript" src="/dialogdocroot/content/javascript/utils.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/mediaelement/build/mediaelement-and-player.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/mediaelement/build/mediaelementplayer.min.js" ></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/mediaelement/src/js/mep-feature-playpause.min.js" ></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/jquery.alphanum.min.js"></script> 

	<link rel="stylesheet" href="/dialogdocroot/content/css/font-awesome/css/font-awesome.min.css" />
	<link rel="stylesheet" href="/dialogdocroot/content/css/nouislider/jquery.nouislider.min.css" />
	<link rel="stylesheet" href="/dialogdocroot/content/css/feedback/ratestyle.min.css" />
	<link rel="stylesheet" href="/dialogdocroot/content/css/jquery-ui.min.css">	
	<link rel="stylesheet" href="/dialogdocroot/content/css/main-custom.min.css">	
	<link rel="stylesheet" href="/dialogdocroot/content/css/main-plus-custom.min.css">
	<link rel="stylesheet" href="/dialogdocroot/content/css/print.min.css" media="print" />
	<link rel="stylesheet" href="/dialogdocroot/content/javascript/vendor/mediaelement/build/mediaelementplayer.min.css" /> 
	<link rel="stylesheet" href="/dialogdocroot/content/css/dialog.min.css" media="screen">
	
	<script src="/dialogdocroot/content/javascript/vendor/respond.min.js"></script>
	<!-- Added By Veranga 18-03-2014 To Dispaly Rignin Tone-->

	<script type="text/javascript" src="/dialogdocroot/content/javascript/zoomit.jquery.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/jquery-ui.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/jquery.bpopup.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/zoom-behavior.min.js"></script>
	<script type="text/javascript" src="/dialogdocroot/content/javascript/feedback/rating.min.js"></script>
	<!-- <script type="text/javascript" src="/dialogdocroot/content/javascript/vendor/jquery.nouislider.js"></script> -->
	<!-- <script type="text/javascript" src="/dialogdocroot/content/javascript/myplan.js"></script> -->
	<script type="text/javascript" src="/dialogdocroot/content/javascript/ringingtones/ringingtones.min.js"></script>

	
	<script type="text/javascript" src="https://connect.dialog.lk/DialogConnect/js/control/dialogConnect.js"></script>
	
	<script type="text/javascript">
		
	
		var contextPath = "/dlg";
	
	</script>

</body>	</html>
